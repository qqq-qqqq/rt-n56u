This directory contains executables that are not compiled.  Some of these may
end up installed for use by end users, but many of them are for use during
development, builds and tests.

Nothing in this directory should need compiling to use and they should be
written such that they do not need configuring (e.g: they might probe several
directories for their requirements)

See the [Scripts Documentation](../docs/Scripts.md) for further details
